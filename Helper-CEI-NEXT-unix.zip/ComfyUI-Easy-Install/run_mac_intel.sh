#!/bin/bash
cd "$(dirname "$0")"

# Intel Macs do not support CUDA (NVIDIA) or MPS (Apple Silicon). Run ComfyUI in CPU mode.

# Clear RAM before starting ComfyUI
echo "Clearing RAM cache to free up memory..."
# Try non-sudo memory clearing techniques first
# Force macOS to drop disk caches and buffer caches
echo 3 > /dev/null 2>&1 || true
# Alternative approach without sudo
python3 -c 'import ctypes; ctypes.CDLL(None).malloc_zone_pressure_relief(0, 0)' 2>/dev/null || true

# Kill any lingering Python processes that might be using memory
echo "Stopping any running Python processes..."
pkill -f "python.*main.py" 2>/dev/null || true

# Give the system a moment to release memory
sleep 1

# CPU stability/compat settings
export PYTORCH_ENABLE_MPS_FALLBACK=0
export COMFYUI_USE_MPS=0
export COMFYUI_FORCE_MPS=0

# Detect Python environment
echo -e "${CYAN}🔍 Detecting Python environment...${RESET}"
PYTHON_BIN=""
if [ -x "python_embeded/bin/python3" ]; then
    PYTHON_BIN="python_embeded/bin/python3"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
elif [ -x "python_embeded_3.12/bin/python3" ]; then
    PYTHON_BIN="python_embeded_3.12/bin/python3"
    echo -e "${GREEN}   ✓ Found Python 3.12${RESET}"
elif [ -x "python_embeded_3.11/bin/python3" ]; then
    PYTHON_BIN="python_embeded_3.11/bin/python3"
    echo -e "${GREEN}   ✓ Found Python 3.11${RESET}"
else
    echo -e "${RED}   ✗ No embedded Python found, using system Python${RESET}"
    PYTHON_BIN="python3"
fi
echo ""

# Show Python being used
if [ -n "$PYTHON_BIN" ]; then
    echo -e "${CYAN}🐍 Activating Python environment...${RESET}"
    sleep 0.5
    echo -e "${GREEN}   ✓ Using: ${YELLOW}${PYTHON_BIN}${RESET}"
    echo ""
fi

# Launch ComfyUI
clear
echo -e "${CYAN}🚀 Launching ComfyUI (CPU mode - Intel Mac)...${RESET}"
echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""
sleep 0.5

"$PYTHON_BIN" -W ignore::FutureWarning ComfyUI/main.py --listen 0.0.0.0 --force-upcast-attention --cpu

echo ""
echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${YELLOW}✨ ComfyUI session ended ✨${RESET}"
echo ""
echo -e "${GREEN}Press any key to exit...${RESET}"
read -n 1 -s
