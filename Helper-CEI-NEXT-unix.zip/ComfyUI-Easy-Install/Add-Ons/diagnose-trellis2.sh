#!/bin/bash

# Comprehensive diagnostic script for Trellis2 dependencies
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_PATH="$SCRIPT_DIR/../python_embeded/python"

echo -e "${green}::::::::::::::: Trellis2 Dependencies Diagnostic${reset}"
echo

# Check Python environment
echo -e "${yellow}=== Python Environment ===${reset}"
echo "Python path: $PYTHON_PATH"
echo "Python version: $($PYTHON_PATH --version 2>&1)"
echo "Python executable: $($PYTHON_PATH -c 'import sys; print(sys.executable)' 2>/dev/null)"
echo "Site packages: $($PYTHON_PATH -c 'import site; print(site.getsitepackages()[0])' 2>/dev/null)"
echo

# Check installed packages
echo -e "${yellow}=== Installed Packages ===${reset}"
echo "Checking pip list for Trellis2 packages..."
$PYTHON_PATH -m pip list | grep -i -E "(nvdiffrast|flex_gemm|cumesh|nvdiffrec|o_voxel)" || echo "No Trellis2 packages found in pip list"
echo

# Check package directories
echo -e "${yellow}=== Package Directories ===${reset}"
SITE_PACKAGES=$("$PYTHON_PATH" -c 'import site; print(site.getsitepackages()[0])' 2>/dev/null)
if [ -n "$SITE_PACKAGES" ]; then
    echo "Searching for nvdiffrast..."
    find "$SITE_PACKAGES" -name "*nvdiffrast*" -type d 2>/dev/null || echo "No nvdiffrast directories found"
    
    echo "Searching for flex_gemm..."
    find "$SITE_PACKAGES" -name "*flex_gemm*" -type d 2>/dev/null || echo "No flex_gemm directories found"
    
    echo "Searching for cumesh..."
    find "$SITE_PACKAGES" -name "*cumesh*" -type d 2>/dev/null || echo "No cumesh directories found"
fi
echo

# Test imports with detailed error info
echo -e "${yellow}=== Import Tests with Details ===${reset}"

echo "Testing nvdiffrast import..."
if "$PYTHON_PATH" -c "import nvdiffrast; print('SUCCESS: nvdiffrast imported'); print('Version:', nvdiffrast.__version__)" 2>&1; then
    echo -e "${green}✓ nvdiffrast import successful${reset}"
else
    echo -e "${red}✗ nvdiffrast import failed${reset}"
fi

echo "Testing flex_gemm import..."
if "$PYTHON_PATH" -c "import flex_gemm; print('SUCCESS: flex_gemm imported')" 2>&1; then
    echo -e "${green}✓ flex_gemm import successful${reset}"
else
    echo -e "${red}✗ flex_gemm import failed${reset}"
fi

echo "Testing cumesh import..."
if "$PYTHON_PATH" -c "import cumesh; print('SUCCESS: cumesh imported')" 2>&1; then
    echo -e "${green}✓ cumesh import successful${reset}"
else
    echo -e "${red}✗ cumesh import failed${reset}"
fi
echo

# Check CUDA and GPU
echo -e "${yellow}=== CUDA/GPU Information ===${reset}"
"$PYTHON_PATH" -c "
import torch
print('PyTorch version:', torch.__version__)
print('CUDA available:', torch.cuda.is_available())
if torch.cuda.is_available():
    print('CUDA version:', torch.version.cuda)
    print('GPU count:', torch.cuda.device_count())
    print('Current device:', torch.cuda.current_device())
    print('GPU name:', torch.cuda.get_device_name(0))
    print('GPU capability:', torch.cuda.get_device_capability(0))
" 2>/dev/null
echo

echo -e "${green}::::::::::::::: Diagnostic Complete${reset}"
