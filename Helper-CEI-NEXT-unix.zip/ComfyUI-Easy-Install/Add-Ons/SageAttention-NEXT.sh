#!/bin/bash
cd "$(dirname "$0")"

node_name="SageAttention"
echo -e "\033]0;'$node_name' for 'ComfyUI Easy Install' by ivo\007"

# Pixaroma Community Edition

# Set colors
warning='\033[33m'
red='\033[91m'
green='\033[92m'
yellow='\033[93m'
bold='\033[1m'
reset='\033[0m'

# Set arguments
PIPargs="--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --use-pep517"

# Check Add-ons folder
PYTHON_PATH="../python_embeded/python"
if [ ! -f "$PYTHON_PATH" ]; then
    # Check for old virtual environment structure
    if [ -f "../python_embeded/bin/python3" ]; then
        PYTHON_PATH="../python_embeded/bin/python3"
    elif [ -f "../python_embeded_3.12/bin/python3" ]; then
        PYTHON_PATH="../python_embeded_3.12/bin/python3"
    elif [ -f "../python_embeded_3.11/bin/python3" ]; then
        PYTHON_PATH="../python_embeded_3.11/bin/python3"
    # Fallback to python3 if not in the expected embedded path
    elif command -v python3 &> /dev/null; then
        PYTHON_PATH=$(command -v python3)
    else
        clear
        echo -e "${green}::::::::::::::: Run this file from the ${red}'ComfyUI-Easy-Install/Add-ons'${green} folder, or ensure python3 is in your PATH.${reset}"
        echo -e "${green}::::::::::::::: Press any key to exit...${reset}"
        read -n 1 -s
        exit
    fi
fi


# Clear Pip Cache - DISABLED to avoid slow connection issues
# if [ -d "$HOME/.cache/pip" ]; then
#     rm -rf "$HOME/.cache/pip"
#     mkdir -p "$HOME/.cache/pip"
# fi
# echo -e "${green}::::::::::::::: Clearing Pip Cache ${yellow}Done${green}${reset}"
# echo

# Get versions
get_versions() {
    echo -e "${green}::::::::::::::: Checking ${yellow}Python, Torch, CUDA ${green}versions${reset}"
    echo

    PYTHON_VERSION=$("$PYTHON_PATH" --version 2>&1 | cut -d' ' -f2 | cut -d'.' -f1,2)
    TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.__version__)" 2>/dev/null | cut -d'.' -f1,2)
    CUDA_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" 2>/dev/null | cut -d'.' -f1,2)

    echo -e "${green}::::::::::::::: Python Version:${yellow} $PYTHON_VERSION${reset}"
    echo -e "${green}::::::::::::::: Torch Version:${yellow} $TORCH_VERSION${reset}"
    echo -e "${green}::::::::::::::: CUDA Version:${yellow} $CUDA_VERSION${reset}"
    echo

    WARNINGS=0

    if [[ "$PYTHON_VERSION" != "3.11" && "$PYTHON_VERSION" != "3.12" ]]; then
        echo -e "${warning}WARNING: ${red}Python $PYTHON_VERSION is not supported. ${green}Supported versions: 3.11, 3.12${reset}"
        WARNINGS=1
    fi
    # Torch might not be installed yet, so check if TORCH_VERSION is empty
    if [ -z "$TORCH_VERSION" ]; then
        echo -e "${warning}WARNING: ${red}Torch is not installed. Please install PyTorch before running this script.${reset}"
        WARNINGS=1
    elif [[ "$TORCH_VERSION" != "2.7" && "$TORCH_VERSION" != "2.8" && "$TORCH_VERSION" != "2.9" ]]; then
        echo -e "${warning}WARNING: ${red}Torch $TORCH_VERSION is not supported. ${green}Supported versions: 2.7, 2.8, 2.9${reset}"
        WARNINGS=1
    fi
    if [[ "$CUDA_VERSION" != "12.8" ]]; then
        echo -e "${warning}WARNING: ${red}CUDA $CUDA_VERSION is not supported. ${green}Supported version: 12.8${reset}"
        WARNINGS=1
    fi

    if [ $WARNINGS -eq 0 ]; then
        echo -e "${green}::::::::::::::: ${reset}${bold}All versions are supported! ${reset}"
        echo
    else
        echo
        echo -e "${red}::::::::::::::: Press any key to exit${reset}"
        read -n 1 -s
        exit
    fi
}

get_versions

# Check for Python development headers
echo -e "${green}::::::::::::::: Checking ${yellow}Python development headers${reset}"
echo

if ! "$PYTHON_PATH" -c "import sysconfig; import os; print(os.path.exists(os.path.join(sysconfig.get_path('include'), 'Python.h')))" 2>/dev/null | grep -q "True"; then
    echo -e "${warning}WARNING: ${red}Python development headers (Python.h) not found.${reset}"
    echo
    echo -e "${yellow}SageAttention requires Python development headers to compile C++ extensions.${reset}"
    echo -e "${yellow}Please install them using one of these methods:${reset}"
    echo
    echo -e "${green}Ubuntu/Debian:${reset}"
    echo -e "  ${bold}sudo apt-get update && sudo apt-get install -y python3.11-dev${reset}"
    echo
    echo -e "${green}RHEL/CentOS/Fedora:${reset}"
    echo -e "  ${bold}sudo yum install -y python3.11-devel${reset}"
    echo
    echo -e "${green}Arch Linux:${reset}"
    echo -e "  ${bold}sudo pacman -S python${reset}"
    echo
    echo -e "${red}::::::::::::::: Press any key to exit${reset}"
    read -n 1 -s
    exit 1
fi

echo -e "${green}::::::::::::::: Python development headers ${yellow}found!${reset}"
echo

# Erasing ~* folders
find "../python_embeded/lib/" -type d -name "~*" -exec rm -rf {} + 2>/dev/null

# Installing build dependencies
echo -e "${green}::::::::::::::: Installing${yellow} build dependencies${reset}"
echo
"$PYTHON_PATH" -m pip install --upgrade wheel setuptools $PIPargs
echo

# Installing Triton
echo -e "${green}::::::::::::::: Installing${yellow} Triton${reset}"
echo
"$PYTHON_PATH" -I -m pip install --upgrade --force-reinstall triton==3.5.0 $PIPargs
echo

# Check CUDA toolkit path for SageAttention build
echo -e "${green}::::::::::::::: Checking${yellow} CUDA toolkit (CUDA_HOME)${reset}"
echo

NVCC_BIN=""
if command -v nvcc >/dev/null 2>&1; then
    NVCC_BIN="$(command -v nvcc)"
elif [ -x "/opt/cuda/bin/nvcc" ]; then
    NVCC_BIN="/opt/cuda/bin/nvcc"
elif [ -x "/usr/local/cuda/bin/nvcc" ]; then
    NVCC_BIN="/usr/local/cuda/bin/nvcc"
fi

if [ -z "$NVCC_BIN" ]; then
    echo -e "${warning}WARNING: ${red}nvcc not found.${reset}"
    echo -e "${yellow}Install CUDA toolkit and ensure nvcc is available.${reset}"
    echo -e "${yellow}On Arch/CachyOS: sudo pacman -S cuda${reset}"
    echo -e "${red}::::::::::::::: Press any key to exit${reset}"
    read -n 1 -s
    exit 1
fi

CUDA_HOME="$(dirname "$(dirname "$NVCC_BIN")")"
export CUDA_HOME
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$LD_LIBRARY_PATH"

# Some SageAttention build paths still expect /usr/local/cuda/bin/nvcc
if [ ! -x "/usr/local/cuda/bin/nvcc" ] && [ "$CUDA_HOME" != "/usr/local/cuda" ]; then
    if [ "$(id -u)" -eq 0 ]; then
        ln -sfn "$CUDA_HOME" /usr/local/cuda
    elif command -v sudo >/dev/null 2>&1; then
        sudo ln -sfn "$CUDA_HOME" /usr/local/cuda || true
    fi
fi

if [ ! -x "/usr/local/cuda/bin/nvcc" ]; then
    echo -e "${warning}WARNING: ${red}/usr/local/cuda/bin/nvcc still missing.${reset}"
    echo -e "${yellow}SageAttention setup may hardcode this path. Create it with:${reset}"
    echo -e "${yellow}  sudo ln -sfn $CUDA_HOME /usr/local/cuda${reset}"
    echo -e "${red}::::::::::::::: Press any key to exit${reset}"
    read -n 1 -s
    exit 1
fi

echo -e "${green}::::::::::::::: CUDA_HOME:${yellow} $CUDA_HOME${reset}"
echo

# Installing SageAttention v2.2.0
echo -e "${green}::::::::::::::: Installing${yellow} $node_name${reset}"
echo

# Create wheels directory for saving built wheels
WHEELS_DIR="../wheels"
mkdir -p "$WHEELS_DIR"
echo -e "${yellow}   ✓ Created wheels directory: $WHEELS_DIR${RESET}"

# Install and save the built wheel
echo -e "${CYAN}   Building and installing SageAttention...${RESET}"
"$PYTHON_PATH" -m pip install --upgrade --no-build-isolation git+https://github.com/thu-ml/SageAttention@v2.2.0 $PIPargs

# Find and copy the built wheel to wheels directory
echo -e "${CYAN}   Saving built wheel...${RESET}"
sleep 2  # Give pip time to finish

# Search for the wheel in common locations
WHEEL_FOUND=""
for cache_dir in ~/.cache/pip/wheels /tmp/pip-ephem-wheel-cache-*; do
    if [ -d "$cache_dir" ]; then
        WHEEL_PATH=$(find "$cache_dir" -name "*sageattention-2.2.0-*.whl" 2>/dev/null | head -1)
        if [ -n "$WHEEL_PATH" ]; then
            cp "$WHEEL_PATH" "$WHEELS_DIR/"
            WHEEL_FOUND=$(basename "$WHEEL_PATH")
            echo -e "${GREEN}   ✓ Saved wheel: $WHEEL_FOUND${RESET}"
            echo -e "${YELLOW}   Location: $WHEELS_DIR/$WHEEL_FOUND${RESET}"
            break
        fi
    fi
done

# If not found in cache, try to find in /tmp
if [ -z "$WHEEL_FOUND" ]; then
    WHEEL_PATH=$(find /tmp -name "*sageattention-2.2.0-*.whl" 2>/dev/null | head -1)
    if [ -n "$WHEEL_PATH" ]; then
        cp "$WHEEL_PATH" "$WHEELS_DIR/"
        WHEEL_FOUND=$(basename "$WHEEL_PATH")
        echo -e "${GREEN}   ✓ Saved wheel: $WHEEL_FOUND${RESET}"
        echo -e "${YELLOW}   Location: $WHEELS_DIR/$WHEEL_FOUND${RESET}"
    fi
fi

if [ -z "$WHEEL_FOUND" ]; then
    echo -e "${YELLOW}   ⚠ Wheel not found in cache (may have been cleaned)${RESET}"
    echo -e "${YELLOW}   To build manually: git clone https://github.com/thu-ml/SageAttention.git && cd SageAttention && python -m build --wheel${RESET}"
fi

echo
# Creating run_nvidia_gpu_SageAttention.sh file
echo
echo -e "${green}::::::::::::::: Creating${yellow} run_nvidia_gpu_SageAttention.sh${reset}"
echo
echo "#!/bin/bash" > ../run_nvidia_gpu_SageAttention.sh
echo "cd \"\$(dirname \"\$0\")\"" >> ../run_nvidia_gpu_SageAttention.sh
echo "echo \"Title ComfyUI-Easy-Install\"" >> ../run_nvidia_gpu_SageAttention.sh

# Add listening address configuration
echo "" >> ../run_nvidia_gpu_SageAttention.sh
echo "# Set listening address (configurable)" >> ../run_nvidia_gpu_SageAttention.sh
echo "LISTEN_CONFIG_FILE=\".listen_address_config\"" >> ../run_nvidia_gpu_SageAttention.sh
echo "LISTEN_ADDRESS=\"\${LISTEN_ADDRESS:-0.0.0.0}\"" >> ../run_nvidia_gpu_SageAttention.sh
echo "" >> ../run_nvidia_gpu_SageAttention.sh
echo "# Load saved setting if exists" >> ../run_nvidia_gpu_SageAttention.sh
echo "if [ -f \"\$LISTEN_CONFIG_FILE\" ]; then" >> ../run_nvidia_gpu_SageAttention.sh
echo "    LISTEN_ADDRESS=\$(cat \"\$LISTEN_CONFIG_FILE\")" >> ../run_nvidia_gpu_SageAttention.sh
echo "fi" >> ../run_nvidia_gpu_SageAttention.sh
echo "" >> ../run_nvidia_gpu_SageAttention.sh
echo "echo \"Listening on: \$LISTEN_ADDRESS\"" >> ../run_nvidia_gpu_SageAttention.sh
echo "./python_embeded/bin/python3 -W ignore::FutureWarning ComfyUI/main.py --use-sage-attention --listen \"\$LISTEN_ADDRESS\"" >> ../run_nvidia_gpu_SageAttention.sh

chmod +x ../run_nvidia_gpu_SageAttention.sh


# Final Messages
echo
echo -e "${GREEN}:::::::::::::::${YELLOW} ${NODE_NAME} ${GREEN}Installation Complete${reset}"
echo
if [ -z "$1" ]; then
    echo -e "${green}::::::::::::::: ${yellow}Press any key to exit${reset}"
    read -n 1 -s
    exit
fi
