#!/bin/bash

# Title: Qwen Edit 2509 Nunchaku Fix for 'ComfyUI Easy Install' by ivo
# Pixaroma Community Edition
# Downloads and replaces qwenimageedit.py in ComfyUI-nunchaku custom node
# Source: https://github.com/nunchaku-tech/ComfyUI-nunchaku/blob/2f991a44e6e20cf1ca04f2ab81df529966b2fe82/models/qwenimage.py

cd "$(dirname "$0")"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
RESET='\033[0m'

echo -e "${GREEN}::::::::::::::: Qwen Edit 2509 Nunchaku Fix :::::::::::::::${RESET}"
echo ""

# Define paths (script is in Add-Ons/Fixes, so go up two levels)
NUNCHAKU_DIR="../../ComfyUI/custom_nodes/ComfyUI-nunchaku/models"
TARGET_FILE="$NUNCHAKU_DIR/qwenimageedit.py"

# URL for the fixed file
FIX_URL="https://raw.githubusercontent.com/nunchaku-tech/ComfyUI-nunchaku/2f991a44e6e20cf1ca04f2ab81df529966b2fe82/models/qwenimage.py"

# Check if target directory exists
if [ ! -d "$NUNCHAKU_DIR" ]; then
    echo -e "${RED}✗ ComfyUI-nunchaku models directory not found at: $NUNCHAKU_DIR${RESET}"
    echo -e "${YELLOW}Make sure ComfyUI-nunchaku is installed in custom_nodes${RESET}"
    exit 1
fi

# Check if target file exists
if [ ! -f "$TARGET_FILE" ]; then
    echo -e "${RED}✗ Target file not found: $TARGET_FILE${RESET}"
    echo -e "${YELLOW}Make sure ComfyUI-nunchaku is properly installed${RESET}"
    exit 1
fi

echo -e "${GREEN}✓${RESET} Found target file: qwenimageedit.py"

# Create backup
echo ""
echo -e "${CYAN}Creating backup...${RESET}"

BACKUP_FILE="$TARGET_FILE.backup"
if [ ! -f "$BACKUP_FILE" ]; then
    cp "$TARGET_FILE" "$BACKUP_FILE"
    echo -e "${GREEN}✓${RESET} Created backup: qwenimageedit.py.backup"
else
    echo -e "${YELLOW}✓${RESET} Backup already exists: qwenimageedit.py.backup"
fi

# Download and apply fix
echo ""
echo -e "${CYAN}Downloading fix from GitHub...${RESET}"

if command -v curl &> /dev/null; then
    curl -sL "$FIX_URL" -o "$TARGET_FILE"
    RESULT=$?
elif command -v wget &> /dev/null; then
    wget -q "$FIX_URL" -O "$TARGET_FILE"
    RESULT=$?
else
    echo -e "${RED}✗ Neither curl nor wget found. Cannot download fix.${RESET}"
    exit 1
fi

if [ $RESULT -eq 0 ]; then
    echo -e "${GREEN}✓${RESET} Downloaded and replaced qwenimageedit.py"
else
    echo -e "${RED}✗${RESET} Failed to download fix"
    echo -e "${YELLOW}Restoring backup...${RESET}"
    cp "$BACKUP_FILE" "$TARGET_FILE"
    exit 1
fi

# Verify the fix was applied
if grep -q "NunchakuQwenImageTransformer2DModel" "$TARGET_FILE"; then
    echo -e "${GREEN}✓${RESET} Fix verified successfully"
else
    echo -e "${YELLOW}!${RESET} Could not verify fix content"
fi

echo ""
echo -e "${GREEN}::::::::::::::: Qwen Edit 2509 Nunchaku Fix Complete :::::::::::::::${RESET}"
echo -e "${YELLOW}Please restart ComfyUI for changes to take effect.${RESET}"
