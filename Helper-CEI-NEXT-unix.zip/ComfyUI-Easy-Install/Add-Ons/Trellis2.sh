#!/bin/bash
cd "$(dirname "$0")"

node_name="Trellis2"
echo -e "\033]0;'$node_name' for ''ComfyUI Easy Install' v0.2.0' by ivo\007"

# Pixaroma Community Edition

# Set colors
warning='\033[33m'
red='\033[91m'
green='\033[92m'
yellow='\033[93m'
bold='\033[1m'
reset='\033[0m'

# Set arguments
PIPargs="--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --use-pep517"

# Check Add-ons folder and locate embedded Python
PYTHON_PATH=""
if [ -f "../python_embeded/python" ]; then
    PYTHON_PATH="../python_embeded/python"
elif [ -f "../python_embeded/bin/python3" ]; then
    PYTHON_PATH="../python_embeded/bin/python3"
elif [ -f "../python_embeded/bin/python" ]; then
    PYTHON_PATH="../python_embeded/bin/python"
fi

if [ -z "$PYTHON_PATH" ]; then
    echo -e "${red}ERROR: Embedded Python not found!${reset}"
    echo -e "${green}::::::::::::::: Run this file from the ${red}'ComfyUI-Easy-Install/Add-Ons'${green} folder${reset}"
    echo -e "${green}::::::::::::::: Press any key to exit...${reset}"
    read -n 1 -s
    exit
fi

echo -e "${green}::::::::::::::: Using Python: ${yellow}$PYTHON_PATH${reset}"

# Clear Pip Cache - DISABLED to avoid slow connection issues
# echo -e "${green}::::::::::::::: Clearing Pip Cache ${yellow}Done${green}${reset}"
# echo

# Get versions
get_versions() {
    echo -e "${green}::::::::::::::: Checking ${yellow}Python, Torch, CUDA ${green}versions${reset}"
    echo

    PYTHON_VERSION=$("$PYTHON_PATH" --version 2>&1 | cut -d' ' -f2 | cut -d'.' -f1,2)
    TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.__version__)" 2>/dev/null | cut -d'.' -f1,2)
    CUDA_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" 2>/dev/null | cut -d'.' -f1,2)

    echo -e "${green}::::::::::::::: Python Version:${yellow} $PYTHON_VERSION${reset}"
    echo -e "${green}::::::::::::::: Torch Version:${yellow} $TORCH_VERSION${reset}"
    echo -e "${green}::::::::::::::: CUDA Version:${yellow} $CUDA_VERSION${reset}"
    echo

    WARNINGS=0

    if [[ "$PYTHON_VERSION" != "3.11" && "$PYTHON_VERSION" != "3.12" ]]; then
        echo -e "${warning}WARNING: ${red}Python $PYTHON_VERSION is not supported. ${green}Supported versions: 3.11, 3.12${reset}"
        WARNINGS=1
    fi
    if [[ "$TORCH_VERSION" != "2.7" && "$TORCH_VERSION" != "2.8" && "$TORCH_VERSION" != "2.9" ]]; then
        echo -e "${warning}WARNING: ${red}Torch $TORCH_VERSION is not supported. ${green}Supported versions: 2.7, 2.8, 2.9${reset}"
        WARNINGS=1
    fi
    if [[ "$CUDA_VERSION" != "12.4" && "$CUDA_VERSION" != "12.8" && "$CUDA_VERSION" != "13.0" ]]; then
        echo -e "${warning}WARNING: ${red}CUDA $CUDA_VERSION is not supported. ${green}Supported versions: 12.4, 12.8, 13.0${reset}"
        WARNINGS=1
    fi

    if [ $WARNINGS -eq 0 ]; then
        echo -e "${green}::::::::::::::: ${reset}${bold}All versions are supported! ${reset}"
        echo
    else
        echo
        echo -e "${red}::::::::::::::: Press any key to exit${reset}"
        read -n 1 -s
        exit
    fi
}

get_versions

# Set model variables
model_url="https://huggingface.co/PIA-SPACE-LAB/dinov3-vitl-pretrain-lvd1689m/resolve/main/model.safetensors"
model_name="model.safetensors"
model_folder="../ComfyUI/models/facebook/dinov3-vitl16-pretrain-lvd1689m"
config_url="https://huggingface.co/PIA-SPACE-LAB/dinov3-vitl-pretrain-lvd1689m/resolve/main/config.json"
config_name="config.json"
pre_config_url="https://huggingface.co/PIA-SPACE-LAB/dinov3-vitl-pretrain-lvd1689m/resolve/main/preprocessor_config.json"
pre_config_name="preprocessor_config.json"

# Check for model.safetensors and its size
if [ -f "$model_folder/$model_name" ]; then
    filesize=$(stat -c%s "$model_folder/$model_name" 2>/dev/null || stat -f%z "$model_folder/$model_name" 2>/dev/null)
    if [ "$filesize" -lt 1212559800 ]; then
        echo -e "${red}The file is incomplete or corrupted - ${yellow}$filesize bytes${red}, deleting...${reset}"
        rm "$model_folder/$model_name"
    fi
fi

# Create model folder if not exists
mkdir -p "$model_folder"

# Download the model
echo -e "${green}Downloading ${yellow}DINOv3 $model_name${reset}"
echo
curl -L -o "$model_folder/$model_name" "$model_url"
curl -L -o "$model_folder/$config_name" "$config_url"
curl -L -o "$model_folder/$pre_config_name" "$pre_config_url"

echo -e "${yellow}DINOv3 $model_name${green} was downloaded successfully${reset}"
echo

# Erasing ~* folders
find "../python_embeded/lib/" -type d -name "~*" -exec rm -rf {} + 2>/dev/null

# Skip downloading LFS
export GIT_LFS_SKIP_SMUDGE=1

# Erase o_voxel folders
rm -rf ../python_embeded/lib/site-packages/o_voxel
rm -rf ../python_embeded/lib/site-packages/o_voxel-0.0.1.dist-info

# Installing Trellis2
echo -e "${green}::::::::::::::: Installing${yellow} $node_name${reset}"
echo
if [ -d "../ComfyUI/custom_nodes/ComfyUI-Trellis2" ]; then
    rm -rf "../ComfyUI/custom_nodes/ComfyUI-Trellis2"
fi
git clone https://github.com/visualbruno/ComfyUI-Trellis2 ../ComfyUI/custom_nodes/ComfyUI-Trellis2
# Determine Python version for wheel selection
PY_MINOR=$("$PYTHON_PATH" -c "import sys; print(sys.version_info.minor)")
if [ "$PY_MINOR" = "12" ]; then
    CP_TAG="cp312"
elif [ "$PY_MINOR" = "11" ]; then
    CP_TAG="cp311"
else
    echo -e "${red}ERROR: Unsupported Python 3.$PY_MINOR for Trellis2 wheels${reset}"
    echo -e "${yellow}Supported: Python 3.11, 3.12${reset}"
    exit 1
fi
echo -e "${green}::::::::::::::: Using wheels for Python 3.$PY_MINOR ($CP_TAG)${reset}"

# Use wheels from cloned repo (like Windows version)
WHEEL_DIR="../ComfyUI/custom_nodes/ComfyUI-Trellis2/wheels/Linux/Torch291"

echo -e "${green}::::::::::::::: Installing Trellis2 wheels from repo${reset}"

# Check which wheels are available
echo -e "${green}::::::::::::::: Checking available wheels${reset}"
for wheel in cumesh-1.0 nvdiffrast-0.4.0 nvdiffrec_render-0.0.0 flex_gemm-0.0.1 o_voxel-0.0.1; do
    if [ -f "$WHEEL_DIR/${wheel}-${CP_TAG}-${CP_TAG}-linux_x86_64.whl" ]; then
        size=$(stat -c%s "$WHEEL_DIR/${wheel}-${CP_TAG}-${CP_TAG}-linux_x86_64.whl" 2>/dev/null || stat -f%z "$WHEEL_DIR/${wheel}-${CP_TAG}-${CP_TAG}-linux_x86_64.whl" 2>/dev/null)
        echo -e "${green}✓ ${wheel} wheel found (${size} bytes)${reset}"
    else
        echo -e "${yellow}✗ ${wheel} wheel not found${reset}"
    fi
done

"$PYTHON_PATH" -I -m pip install -r ../ComfyUI/custom_nodes/ComfyUI-Trellis2/requirements.txt --no-deps $PIPargs
echo

# Install Trellis2 wheels (with fallback to pip)
echo -e "${green}::::::::::::::: Installing Trellis2 wheels${reset}"

# Install cumesh FIRST (before o_voxel to prevent it from pulling old repo)
if [ -f "$WHEEL_DIR/cumesh-1.0-${CP_TAG}-${CP_TAG}-linux_x86_64.whl" ]; then
    echo -e "${green}Installing cumesh from wheel${reset}"
    "$PYTHON_PATH" -I -m pip install "$WHEEL_DIR/cumesh-1.0-${CP_TAG}-${CP_TAG}-linux_x86_64.whl" --force-reinstall --no-deps
else
    echo -e "${yellow}Installing cumesh from pip (wheel not available)${reset}"
    "$PYTHON_PATH" -I -m pip install git+https://github.com/visualbruno/CuMesh.git --no-deps $PIPargs || echo -e "${red}cumesh installation failed${reset}"
fi

# Install nvdiffrast
if [ -f "$WHEEL_DIR/nvdiffrast-0.4.0-${CP_TAG}-${CP_TAG}-linux_x86_64.whl" ]; then
    echo -e "${green}Installing nvdiffrast from wheel${reset}"
    "$PYTHON_PATH" -I -m pip install "$WHEEL_DIR/nvdiffrast-0.4.0-${CP_TAG}-${CP_TAG}-linux_x86_64.whl" --force-reinstall --no-deps
else
    echo -e "${yellow}Installing nvdiffrast from pip (wheel not available)${reset}"
    "$PYTHON_PATH" -I -m pip install nvdiffrast --no-deps $PIPargs || echo -e "${red}nvdiffrast installation failed${reset}"
fi

# Install nvdiffrec_render
if [ -f "$WHEEL_DIR/nvdiffrec_render-0.0.0-${CP_TAG}-${CP_TAG}-linux_x86_64.whl" ]; then
    echo -e "${green}Installing nvdiffrec_render from wheel${reset}"
    "$PYTHON_PATH" -I -m pip install "$WHEEL_DIR/nvdiffrec_render-0.0.0-${CP_TAG}-${CP_TAG}-linux_x86_64.whl" --force-reinstall --no-deps
else
    echo -e "${yellow}Installing nvdiffrec_render from pip (wheel not available)${reset}"
    "$PYTHON_PATH" -I -m pip install git+https://github.com/JeffreyXiang/nvdiffrec.git@renderutils --no-deps $PIPargs || echo -e "${red}nvdiffrec_render installation failed${reset}"
fi

# Install flex_gemm
if [ -f "$WHEEL_DIR/flex_gemm-0.0.1-${CP_TAG}-${CP_TAG}-linux_x86_64.whl" ]; then
    echo -e "${green}Installing flex_gemm from wheel${reset}"
    "$PYTHON_PATH" -I -m pip install "$WHEEL_DIR/flex_gemm-0.0.1-${CP_TAG}-${CP_TAG}-linux_x86_64.whl" --force-reinstall --no-deps
else
    echo -e "${yellow}Installing flex_gemm from pip (wheel not available)${reset}"
    "$PYTHON_PATH" -I -m pip install git+https://github.com/visualbruno/FlexGEMM.git --no-deps $PIPargs || echo -e "${red}flex_gemm installation failed${reset}"
fi

# Install o_voxel LAST (after cumesh is already installed)
if [ -f "$WHEEL_DIR/o_voxel-0.0.1-${CP_TAG}-${CP_TAG}-linux_x86_64.whl" ]; then
    echo -e "${green}Installing o_voxel from wheel${reset}"
    "$PYTHON_PATH" -I -m pip install "$WHEEL_DIR/o_voxel-0.0.1-${CP_TAG}-${CP_TAG}-linux_x86_64.whl" --force-reinstall --no-deps
else
    echo -e "${yellow}Installing o_voxel from pip (wheel not available)${reset}"
    "$PYTHON_PATH" -I -m pip install git+https://github.com/microsoft/TRELLIS.2.git#subdirectory=o-voxel --no-deps $PIPargs || echo -e "${red}o_voxel installation failed${reset}"
fi

"$PYTHON_PATH" -I -m pip install --force-reinstall numpy==1.26.4 --no-deps $PIPargs

# Final Messages
echo
echo -e "${green}:::::::::::::::${yellow} $node_name ${green}Installation Complete${reset}"
echo
if [ -z "$1" ]; then
    echo -e "${green}::::::::::::::: ${yellow}Press any key to exit${reset}"
    read -n 1 -s
    exit
fi
