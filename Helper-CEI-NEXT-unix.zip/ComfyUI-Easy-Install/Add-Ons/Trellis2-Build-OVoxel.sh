#!/bin/bash

# Build o_voxel wheel from Microsoft TRELLIS.2 repo
# This package is not publicly available as a separate repo

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RESET='\033[0m'

echo -e "${GREEN}::::::::::::::: o_voxel Wheel Builder${RESET}"
echo

# Get script directory and Python path
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_PATH="$SCRIPT_DIR/../python_embeded/python"
WHEELS_DIR="$SCRIPT_DIR/wheels/Linux/Torch291_cu130"

# Check Python exists
if [ ! -f "$PYTHON_PATH" ]; then
    echo -e "${RED}ERROR: Python not found at $PYTHON_PATH${RESET}"
    exit 1
fi

echo -e "${GREEN}Python: ${YELLOW}$PYTHON_PATH${RESET}"
echo -e "${GREEN}Wheels Dir: ${YELLOW}$WHEELS_DIR${RESET}"
echo

# Create wheels directory
mkdir -p "$WHEELS_DIR"

# Check CUDA toolkit
if [ ! -d "/usr/local/cuda" ]; then
    echo -e "${RED}ERROR: CUDA toolkit not found at /usr/local/cuda${RESET}"
    exit 1
fi

export CUDA_HOME="/usr/local/cuda"
echo -e "${GREEN}✓ CUDA Home: ${YELLOW}$CUDA_HOME${RESET}"

# Detect GPU architecture
GPU_ARCH=$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader 2>/dev/null | head -n1 | tr -d '.')
if [ -n "$GPU_ARCH" ]; then
    GPU_NAME=$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -n1)
    echo -e "${GREEN}✓ GPU: ${YELLOW}$GPU_NAME (SM_$GPU_ARCH)${RESET}"
    
    # Set CUDA arch based on GPU
    case "$GPU_ARCH" in
        "86") export TORCH_CUDA_ARCH_LIST="8.6" ;;
        "89") export TORCH_CUDA_ARCH_LIST="8.9" ;;
        "80") export TORCH_CUDA_ARCH_LIST="8.0" ;;
        "120") export TORCH_CUDA_ARCH_LIST="12.0" ;;
        *) export TORCH_CUDA_ARCH_LIST="8.0;8.6;8.9" ;;
    esac
    echo -e "${GREEN}✓ CUDA Arch: ${YELLOW}$TORCH_CUDA_ARCH_LIST${RESET}"
else
    echo -e "${YELLOW}⚠ No GPU detected, using default arch list${RESET}"
    export TORCH_CUDA_ARCH_LIST="8.0;8.6;8.9"
fi
echo

# Build directory
BUILD_DIR="/tmp/o_voxel_build"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

echo -e "${GREEN}::::::::::::::: Cloning Microsoft TRELLIS.2${RESET}"
git clone https://github.com/microsoft/TRELLIS.2 --depth 1 --recursive || {
    echo -e "${RED}✗ Failed to clone TRELLIS.2${RESET}"
    exit 1
}

cd TRELLIS.2

# Ensure submodules are initialized
echo -e "${GREEN}::::::::::::::: Initializing submodules${RESET}"
git submodule update --init --recursive

# Check o-voxel exists
if [ ! -d "o-voxel" ]; then
    echo -e "${RED}✗ o-voxel folder not found in TRELLIS.2${RESET}"
    exit 1
fi

# Check eigen submodule
if [ ! -d "o-voxel/third_party/eigen/Eigen" ]; then
    echo -e "${RED}✗ Eigen submodule not found${RESET}"
    echo -e "${YELLOW}Trying manual clone...${RESET}"
    rm -rf o-voxel/third_party/eigen
    git clone https://gitlab.com/libeigen/eigen.git o-voxel/third_party/eigen --depth 1
fi

cd o-voxel

# Install dependencies BEFORE building
echo -e "${GREEN}::::::::::::::: Installing dependencies${RESET}"
"$PYTHON_PATH" -m pip install plyfile zstandard

echo -e "${GREEN}::::::::::::::: Building o_voxel wheel${RESET}"
export CUDA_HOME="$CUDA_HOME"
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$LD_LIBRARY_PATH"

"$PYTHON_PATH" -m pip wheel . --no-build-isolation --no-deps --wheel-dir="$WHEELS_DIR" --verbose || {
    echo -e "${RED}✗ Failed to build o_voxel wheel${RESET}"
    exit 1
}

echo -e "${GREEN}✓ o_voxel wheel built successfully${RESET}"
echo

# Find the wheel
WHEEL_FILE=$(ls "$WHEELS_DIR"/o_voxel-*.whl 2>/dev/null | head -n1)
if [ -z "$WHEEL_FILE" ]; then
    echo -e "${RED}✗ Wheel file not found${RESET}"
    exit 1
fi

echo -e "${GREEN}::::::::::::::: Installing o_voxel${RESET}"
"$PYTHON_PATH" -m pip install "$WHEEL_FILE" --force-reinstall --no-deps || {
    echo -e "${RED}✗ Failed to install o_voxel${RESET}"
    exit 1
}

# Verify installation
echo -e "${GREEN}::::::::::::::: Verifying o_voxel${RESET}"
cd /tmp
"$PYTHON_PATH" -c "import o_voxel; print('o_voxel imported successfully')" || {
    echo -e "${RED}✗ o_voxel import failed${RESET}"
    exit 1
}

echo
echo -e "${GREEN}✓ o_voxel installation complete!${RESET}"
echo -e "${YELLOW}Wheel saved: $WHEEL_FILE${RESET}"
echo

# Cleanup
rm -rf "$BUILD_DIR"

if [ -z "$1" ]; then
    echo -e "${GREEN}::::::::::::::: ${YELLOW}Press any key to exit${RESET}"
    read -n 1 -s
fi
