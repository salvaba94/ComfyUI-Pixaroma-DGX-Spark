#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

SCRIPT_NAME="cuda-toolkit-installer.sh"
TITLE="Universal CUDA Toolkit Installer"

# Colors
RED='\033[91m'
GREEN='\033[92m'
YELLOW='\033[93m'
BOLD='\033[1m'
RESET='\033[0m'

# Defaults
REQUESTED_CUDA=""
NON_INTERACTIVE=0
CHECK_ONLY=0
AUTO_YES=0
INSTALL_DRIVER=0
EMBEDDED_PYTHON=""

print_usage() {
    cat <<EOF
Usage:
  ./$SCRIPT_NAME                          # Interactive mode
  ./$SCRIPT_NAME --cuda 12               # Alias for latest supported 12.x (12.9)
  ./$SCRIPT_NAME --cuda 13 --yes         # Alias for latest supported 13.x (13.1)
  ./$SCRIPT_NAME --cuda 12.9             # Explicit version
  ./$SCRIPT_NAME --cuda 13.0             # Explicit version
  ./$SCRIPT_NAME --cuda 13.1             # Explicit version
  ./$SCRIPT_NAME --check-only            # Only run checks, no install
  ./$SCRIPT_NAME --embedded-python PATH  # Torch check with embedded python

Options:
  --cuda <12|13|12.9|13.0|13.1>
                         Requested CUDA toolkit version
  --non-interactive      Do not prompt; requires --cuda for install mode
  --check-only           Skip installation, only validate nvcc + torch alignment
  --embedded-python PATH Python executable for torch CUDA check
  --with-driver          Allow driver installation path (default: toolkit-only)
  --yes                  Auto-confirm prompts
  -h, --help             Show this help
EOF
}

log() {
    echo -e "${GREEN}:::::::::::::::${YELLOW} $* ${GREEN}:::::::::::::::${RESET}"
}

warn() {
    echo -e "${YELLOW}WARNING:${RESET} $*"
}

err() {
    echo -e "${RED}ERROR:${RESET} $*"
}

have_cmd() {
    command -v "$1" >/dev/null 2>&1
}

confirm() {
    local prompt="$1"
    if [[ $AUTO_YES -eq 1 ]]; then
        return 0
    fi
    read -r -p "$prompt [y/N]: " ans
    [[ "$ans" =~ ^[Yy]$ ]]
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --cuda)
                REQUESTED_CUDA="${2:-}"
                shift 2
                ;;
            --non-interactive)
                NON_INTERACTIVE=1
                shift
                ;;
            --check-only)
                CHECK_ONLY=1
                shift
                ;;
            --embedded-python)
                EMBEDDED_PYTHON="${2:-}"
                shift 2
                ;;
            --with-driver)
                INSTALL_DRIVER=1
                shift
                ;;
            --yes)
                AUTO_YES=1
                shift
                ;;
            -h|--help)
                print_usage
                exit 0
                ;;
            *)
                err "Unknown argument: $1"
                print_usage
                exit 1
                ;;
        esac
    done

    if [[ -n "$REQUESTED_CUDA" && ! "$REQUESTED_CUDA" =~ ^(12|13|12\.9|13\.0|13\.1)$ ]]; then
        err "--cuda must be one of: 12, 13, 12.9, 13.0, 13.1"
        exit 1
    fi

    if [[ $CHECK_ONLY -eq 0 && $NON_INTERACTIVE -eq 1 && -z "$REQUESTED_CUDA" ]]; then
        err "--non-interactive install requires --cuda (12, 13, 12.9, 13.0, or 13.1)"
        exit 1
    fi
}

normalize_requested_cuda() {
    case "$REQUESTED_CUDA" in
        "12") REQUESTED_CUDA="12.9" ;;
        "13") REQUESTED_CUDA="13.1" ;;
    esac
}

requested_cuda_major() {
    echo "${REQUESTED_CUDA%%.*}"
}

detect_embedded_python() {
    if [[ -n "$EMBEDDED_PYTHON" ]]; then
        return
    fi

    if [[ -x "../python_embeded/python" ]]; then
        EMBEDDED_PYTHON="../python_embeded/python"
    elif [[ -x "../python_embeded/bin/python3" ]]; then
        EMBEDDED_PYTHON="../python_embeded/bin/python3"
    else
        EMBEDDED_PYTHON=""
    fi
}

detect_pm() {
    if have_cmd pacman; then
        echo "pacman"
    elif have_cmd apt-get; then
        echo "apt"
    elif have_cmd dnf; then
        echo "dnf"
    elif have_cmd zypper; then
        echo "zypper"
    else
        echo "unknown"
    fi
}

prompt_cuda_major() {
    if [[ -n "$REQUESTED_CUDA" || $CHECK_ONLY -eq 1 ]]; then
        return
    fi

    if [[ $NON_INTERACTIVE -eq 1 ]]; then
        return
    fi

    echo
    echo -e "${BOLD}Select CUDA toolkit version:${RESET}"
    echo "  1) CUDA 12.9"
    echo "  2) CUDA 13.0"
    echo "  3) CUDA 13.1"
    read -r -p "Choice [1-3]: " choice

    case "$choice" in
        1) REQUESTED_CUDA="12.9" ;;
        2) REQUESTED_CUDA="13.0" ;;
        3) REQUESTED_CUDA="13.1" ;;
        *)
            err "Invalid selection"
            exit 1
            ;;
    esac
}

pick_runfile_url() {
    # Known stable installer URLs. Update as needed.
    if [[ "$REQUESTED_CUDA" == "12.9" ]]; then
        echo "https://developer.download.nvidia.com/compute/cuda/12.9.1/local_installers/cuda_12.9.1_575.57.08_linux.run"
    elif [[ "$REQUESTED_CUDA" == "13.0" ]]; then
        echo "https://developer.download.nvidia.com/compute/cuda/13.0.2/local_installers/cuda_13.0.2_580.65.06_linux.run"
    elif [[ "$REQUESTED_CUDA" == "13.1" ]]; then
        # Set this env var if NVIDIA renames the runfile in future releases.
        if [[ -n "${CUDA_13_1_RUNFILE_URL:-}" ]]; then
            echo "$CUDA_13_1_RUNFILE_URL"
        else
            echo "https://developer.download.nvidia.com/compute/cuda/13.1.0/local_installers/cuda_13.1.0_580.95.05_linux.run"
        fi
    else
        err "No runfile mapping for requested CUDA version: $REQUESTED_CUDA"
        exit 1
    fi
}

try_install_with_pm() {
    local pm="$1"
    local ok=0

    log "Installing CUDA toolkit ${REQUESTED_CUDA} via $pm"

    case "$pm" in
        pacman)
            sudo pacman -Syu --noconfirm
            sudo pacman -S --noconfirm cuda && ok=1 || ok=0
            ;;
        apt)
            sudo apt-get update
            if [[ "$REQUESTED_CUDA" == "12.9" ]]; then
                sudo apt-get install -y cuda-toolkit-12-9 && ok=1 || ok=0
            elif [[ "$REQUESTED_CUDA" == "13.0" ]]; then
                sudo apt-get install -y cuda-toolkit-13-0 && ok=1 || ok=0
            else
                sudo apt-get install -y cuda-toolkit-13-1 && ok=1 || ok=0
            fi
            if [[ $ok -eq 0 ]]; then
                warn "Versioned package failed, trying generic cuda-toolkit"
                sudo apt-get install -y cuda-toolkit && ok=1 || ok=0
            fi
            ;;
        dnf)
            if [[ "$REQUESTED_CUDA" == "12.9" ]]; then
                sudo dnf install -y cuda-toolkit-12-9 && ok=1 || ok=0
            elif [[ "$REQUESTED_CUDA" == "13.0" ]]; then
                sudo dnf install -y cuda-toolkit-13-0 && ok=1 || ok=0
            else
                sudo dnf install -y cuda-toolkit-13-1 && ok=1 || ok=0
            fi
            if [[ $ok -eq 0 ]]; then
                warn "Versioned package failed, trying generic cuda-toolkit"
                sudo dnf install -y cuda-toolkit && ok=1 || ok=0
            fi
            ;;
        zypper)
            sudo zypper --non-interactive install cuda-toolkit && ok=1 || ok=0
            ;;
        *)
            ok=0
            ;;
    esac

    return $ok
}

install_with_runfile() {
    local url
    local runfile

    url="$(pick_runfile_url)"
    runfile="/tmp/$(basename "$url")"

    log "Falling back to NVIDIA runfile (${REQUESTED_CUDA})"
    echo "URL: $url"

    if have_cmd wget; then
        wget -O "$runfile" "$url"
    elif have_cmd curl; then
        curl -L "$url" -o "$runfile"
    else
        err "Neither wget nor curl is available"
        exit 1
    fi

    chmod +x "$runfile"

    if [[ $INSTALL_DRIVER -eq 1 ]]; then
        sudo sh "$runfile" --silent
    else
        sudo sh "$runfile" --silent --toolkit
    fi
}

find_nvcc() {
    if have_cmd nvcc; then
        command -v nvcc
        return 0
    fi
    if [[ -x /opt/cuda/bin/nvcc ]]; then
        echo /opt/cuda/bin/nvcc
        return 0
    fi
    if [[ -x /usr/local/cuda/bin/nvcc ]]; then
        echo /usr/local/cuda/bin/nvcc
        return 0
    fi
    return 1
}

find_matching_cuda_home() {
    local requested="$1"
    local major="${requested%%.*}"
    local candidate=""

    # Prefer exact requested version first
    candidate="$(ls -d /opt/cuda-${requested}* /usr/local/cuda-${requested}* 2>/dev/null | sort -V | tail -n1 || true)"
    if [[ -z "$candidate" ]]; then
        # Fallback to major match
        candidate="$(ls -d /opt/cuda-${major}* /usr/local/cuda-${major}* 2>/dev/null | sort -V | tail -n1 || true)"
    fi
    echo "$candidate"
}

normalize_cuda_symlink() {
    local target="$1"
    if [[ -z "$target" ]]; then
        return 1
    fi
    sudo ln -sfn "$target" /usr/local/cuda
    return 0
}

nvcc_version_mm() {
    nvcc --version | sed -n 's/.*release \([0-9]\+\.[0-9]\+\).*/\1/p' | head -1
}

torch_cuda_mm() {
    local py="$1"
    "$py" -c "import torch; print(torch.version.cuda or '')" 2>/dev/null | cut -d'.' -f1,2
}

run_preflight_checks() {
    local nvcc_bin nvcc_mm torch_mm
    local py_ver torch_ver torch_cuda_ver py_headers_ok
    local warnings=0

    log "Preflight check (before installation)"

    nvcc_bin="$(find_nvcc || true)"
    if [[ -n "$nvcc_bin" ]]; then
        nvcc_mm="$("$nvcc_bin" --version 2>/dev/null | sed -n 's/.*release \([0-9]\+\.[0-9]\+\).*/\1/p' | head -1)"
        echo -e "${GREEN}Current nvcc path:${YELLOW} $nvcc_bin${RESET}"
        echo -e "${GREEN}Current nvcc version:${YELLOW} ${nvcc_mm:-unknown}${RESET}"
    else
        warn "nvcc not found on current PATH/known locations"
    fi

    detect_embedded_python
    if [[ -n "$EMBEDDED_PYTHON" && -x "$EMBEDDED_PYTHON" ]]; then
        py_ver="$("$EMBEDDED_PYTHON" --version 2>&1 | awk '{print $2}' | cut -d'.' -f1,2)"
        torch_ver="$("$EMBEDDED_PYTHON" -c "import torch; print(torch.__version__)" 2>/dev/null | cut -d'.' -f1,2)"
        torch_cuda_ver="$("$EMBEDDED_PYTHON" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" 2>/dev/null | cut -d'.' -f1,2)"
        torch_mm="$(torch_cuda_mm "$EMBEDDED_PYTHON" || true)"

        echo -e "${GREEN}Embedded python:${YELLOW} $EMBEDDED_PYTHON${RESET}"
        echo -e "${GREEN}Python version:${YELLOW} ${py_ver:-unknown}${RESET}"
        echo -e "${GREEN}Torch version:${YELLOW} ${torch_ver:-unknown}${RESET}"
        echo -e "${GREEN}Torch CUDA available:${YELLOW} ${torch_cuda_ver:-unknown}${RESET}"
        echo -e "${GREEN}Current torch.version.cuda:${YELLOW} ${torch_mm:-unknown}${RESET}"

        # Minimum compatibility checks (mirrors SageAttention prechecks)
        if [[ -z "$py_ver" || ( "${py_ver%%.*}" -lt 3 ) || ( "${py_ver%%.*}" -eq 3 && "${py_ver##*.}" -lt 8 ) ]]; then
            warn "Python ${py_ver:-unknown} may be unsupported (expected >= 3.8)"
            warnings=1
        fi

        if [[ -z "$torch_ver" || "${torch_ver%%.*}" -lt 2 ]]; then
            warn "Torch ${torch_ver:-unknown} may be unsupported (expected >= 2.0)"
            warnings=1
        fi

        if [[ "$torch_cuda_ver" == "Not" || "$torch_cuda_ver" == "Not available" || -z "$torch_cuda_ver" ]]; then
            warn "Torch CUDA is not available in embedded environment"
            warnings=1
        fi

        py_headers_ok="$("$EMBEDDED_PYTHON" -c "import sysconfig, os; print(os.path.exists(os.path.join(sysconfig.get_path('include'), 'Python.h')))" 2>/dev/null || echo "False")"
        if [[ "$py_headers_ok" == "True" ]]; then
            echo -e "${GREEN}Python development headers:${YELLOW} found${RESET}"
        else
            warn "Python development headers (Python.h) not found for embedded Python"
            warnings=1
        fi
    else
        warn "Embedded python not found; skipping torch preflight check"
        warnings=1
    fi

    if [[ $warnings -eq 0 ]]; then
        echo -e "${GREEN}Preflight summary:${YELLOW} all core checks look good${RESET}"
    else
        echo -e "${YELLOW}Preflight summary:${RESET} warnings detected; installation can continue, but compatibility issues may appear."
    fi

    echo
}

run_checks() {
    local nvcc_bin cuda_home nvcc_mm torch_mm target_home
    local requested_major=""

    log "Running CUDA checks"

    nvcc_bin="$(find_nvcc || true)"
    if [[ -z "$nvcc_bin" ]]; then
        err "nvcc not found"
        return 1
    fi

    cuda_home="$(dirname "$(dirname "$nvcc_bin")")"
    export CUDA_HOME="$cuda_home"
    export PATH="$CUDA_HOME/bin:$PATH"
    export LD_LIBRARY_PATH="$CUDA_HOME/lib64:${LD_LIBRARY_PATH:-}"

    nvcc_mm="$(nvcc_version_mm || true)"
    echo -e "${GREEN}CUDA_HOME:${YELLOW} $CUDA_HOME${RESET}"
    echo -e "${GREEN}nvcc version:${YELLOW} ${nvcc_mm:-unknown}${RESET}"

    if [[ -n "$REQUESTED_CUDA" ]]; then
        requested_major="$(requested_cuda_major)"
    fi

    if [[ -n "$REQUESTED_CUDA" && ( "$nvcc_mm" != "$REQUESTED_CUDA" && "${nvcc_mm%%.*}" != "$requested_major" ) ]]; then
        warn "Requested CUDA $REQUESTED_CUDA, but nvcc is $nvcc_mm"
        target_home="$(find_matching_cuda_home "$REQUESTED_CUDA")"
        if [[ -n "$target_home" ]]; then
            warn "Switching /usr/local/cuda to $target_home"
            normalize_cuda_symlink "$target_home"
            export CUDA_HOME="/usr/local/cuda"
            export PATH="$CUDA_HOME/bin:$PATH"
            export LD_LIBRARY_PATH="$CUDA_HOME/lib64:${LD_LIBRARY_PATH:-}"
            nvcc_mm="$(nvcc_version_mm || true)"
            echo -e "${GREEN}After switch nvcc version:${YELLOW} ${nvcc_mm:-unknown}${RESET}"
        else
            warn "No installed CUDA directory found for requested version $REQUESTED_CUDA"
        fi
    fi

    detect_embedded_python
    if [[ -n "$EMBEDDED_PYTHON" && -x "$EMBEDDED_PYTHON" ]]; then
        torch_mm="$(torch_cuda_mm "$EMBEDDED_PYTHON" || true)"
        echo -e "${GREEN}Embedded python:${YELLOW} $EMBEDDED_PYTHON${RESET}"
        echo -e "${GREEN}torch.version.cuda:${YELLOW} ${torch_mm:-unknown}${RESET}"

        if [[ -n "$torch_mm" && -n "$nvcc_mm" && "$torch_mm" != "$nvcc_mm" ]]; then
            warn "Torch CUDA ($torch_mm) and nvcc ($nvcc_mm) mismatch"
            echo -e "${YELLOW}For SageAttention builds, align them.${RESET}"
            echo -e "${YELLOW}Tip: install toolkit matching torch, then point /usr/local/cuda to it.${RESET}"
            return 2
        fi
    else
        warn "Embedded python not found; skipping torch compatibility check"
    fi

    return 0
}

main() {
    echo -e "${BOLD}$TITLE${RESET}"
    parse_args "$@"
    normalize_requested_cuda
    prompt_cuda_major
    run_preflight_checks

    if [[ $CHECK_ONLY -eq 1 ]]; then
        run_checks || true
        exit 0
    fi

    if [[ -z "$REQUESTED_CUDA" ]]; then
        err "No CUDA version selected"
        exit 1
    fi

    echo
    echo -e "${GREEN}Install plan:${RESET} CUDA ${REQUESTED_CUDA}"
    if [[ $INSTALL_DRIVER -eq 1 ]]; then
        echo -e "${YELLOW}- Mode:${RESET} toolkit + driver"
    else
        echo -e "${YELLOW}- Mode:${RESET} toolkit only (recommended)"
    fi

    if ! confirm "Proceed with installation?"; then
        echo "Cancelled."
        exit 0
    fi

    local pm
    pm="$(detect_pm)"

    if ! try_install_with_pm "$pm"; then
        warn "Package-manager install path failed or unsupported"
        if confirm "Try NVIDIA runfile fallback?"; then
            install_with_runfile
        else
            err "Installation aborted"
            exit 1
        fi
    fi

    run_checks || true

    echo
    log "Done"
    echo -e "${YELLOW}Current shell exports (if needed):${RESET}"
    echo "  export CUDA_HOME=/usr/local/cuda"
    echo "  export PATH=\$CUDA_HOME/bin:\$PATH"
    echo "  export LD_LIBRARY_PATH=\$CUDA_HOME/lib64:\$LD_LIBRARY_PATH"
}

main "$@"
