#!/bin/bash

# Install Trellis2 Pre-built Wheels from visualbruno's repo
# Much faster than building from source!

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'
RESET='\033[0m'

# Get script directory and Python path
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_PATH="$SCRIPT_DIR/../python_embeded/python"
WHEELS_DIR="$SCRIPT_DIR/trellis2_prebuilt"

echo -e "${GREEN}::::::::::::::: Trellis2 Pre-built Wheels Installer${RESET}"
echo -e "${GREEN}::::::::::::::: Python: ${YELLOW}$PYTHON_PATH${RESET}"
echo -e "${GREEN}::::::::::::::: Wheels Dir: ${YELLOW}$WHEELS_DIR${RESET}"
echo

# Check Python
if [ ! -f "$PYTHON_PATH" ]; then
    echo -e "${RED}ERROR: Embedded Python not found!${RESET}"
    exit 1
fi

# Get Torch version
TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.__version__)" 2>/dev/null | cut -d'.' -f1,2)
echo -e "${GREEN}✓ Detected Torch: ${YELLOW}$TORCH_VERSION${RESET}"

# Select appropriate wheel directory
if [ "$TORCH_VERSION" = "2.9" ] || [ "$TORCH_VERSION" = "2.10" ]; then
    WHEEL_VERSION="Torch291"
    echo -e "${GREEN}✓ Using wheels for: ${YELLOW}$WHEEL_VERSION${RESET}"
else
    echo -e "${RED}ERROR: Torch $TORCH_VERSION not supported by pre-built wheels${RESET}"
    echo -e "${YELLOW}Supported versions: 2.9, 2.10${RESET}"
    exit 1
fi

# Create wheels directory
mkdir -p "$WHEELS_DIR"
cd "$WHEELS_DIR"

# Base URL for wheels
BASE_URL="https://raw.githubusercontent.com/visualbruno/ComfyUI-Trellis2/main/wheels/Linux/$WHEEL_VERSION"

# List of wheels to download
declare -A WHEELS=(
    ["cumesh"]="cumesh-0.0.1-cp312-cp312-linux_x86_64.whl"
    ["flex_gemm"]="flex_gemm-0.0.1-cp312-cp312-linux_x86_64.whl"
    ["nvdiffrast"]="nvdiffrast-0.4.0-cp312-cp312-linux_x86_64.whl"
    ["nvdiffrec_render"]="nvdiffrec_render-0.0.0-cp312-cp312-linux_x86_64.whl"
    ["o_voxel"]="o_voxel-0.0.1-cp312-cp312-linux_x86_64.whl"
)

# Download wheels
echo -e "${GREEN}::::::::::::::: Downloading Wheels${RESET}"
echo

for package in "${!WHEELS[@]}"; do
    wheel_file="${WHEELS[$package]}"
    wheel_url="$BASE_URL/$wheel_file"
    
    echo -e "${YELLOW}Downloading: $wheel_file${RESET}"
    
    if curl -L -o "$wheel_file" "$wheel_url"; then
        echo -e "${GREEN}✓ Downloaded $wheel_file${RESET}"
    else
        echo -e "${RED}✗ Failed to download $wheel_file${RESET}"
        exit 1
    fi
done

echo
echo -e "${GREEN}::::::::::::::: Installing Wheels${RESET}"
echo

# Install dependencies first
echo -e "${YELLOW}Installing dependencies...${RESET}"
"$PYTHON_PATH" -m pip install plyfile zstandard --no-cache-dir

# Install wheels with --no-deps to avoid conflicts
for package in "${!WHEELS[@]}"; do
    wheel_file="${WHEELS[$package]}"
    
    echo -e "${YELLOW}Installing: $wheel_file${RESET}"
    if "$PYTHON_PATH" -m pip install "$wheel_file" --force-reinstall --no-deps --no-cache-dir; then
        echo -e "${GREEN}✓ Installed $package${RESET}"
    else
        echo -e "${RED}✗ Failed to install $package${RESET}"
        exit 1
    fi
done

echo
echo -e "${GREEN}::::::::::::::: Verifying Installation${RESET}"
echo

# Test imports
packages=("cumesh" "flex_gemm" "nvdiffrast" "o_voxel")
for package in "${packages[@]}"; do
    if "$PYTHON_PATH" -c "import $package; print('✓ $package imported successfully')" 2>/dev/null; then
        echo -e "${GREEN}✓ $package is working${RESET}"
    else
        echo -e "${RED}✗ $package failed${RESET}"
    fi
done

# Test nvdiffrec_render (import as 'render')
if "$PYTHON_PATH" -c "import render; print('✓ nvdiffrec_render imported successfully')" 2>/dev/null; then
    echo -e "${GREEN}✓ nvdiffrec_render is working${RESET}"
else
    echo -e "${RED}✗ nvdiffrec_render failed${RESET}"
fi

echo
echo -e "${GREEN}::::::::::::::: Installation Complete!${RESET}"
echo -e "${YELLOW}Trellis2 dependencies are ready for use!${RESET}"
echo -e "${YELLOW}Wheels saved in: $WHEELS_DIR${RESET}"

# Install FlashAttention separately (not included in pre-built wheels)
echo
echo -e "${GREEN}::::::::::::::: Installing FlashAttention${RESET}"
echo -e "${YELLOW}Note: FlashAttention needs to be built from source${RESET}"

MAX_JOBS=4 "$PYTHON_PATH" -m pip install flash-attn --no-build-isolation --no-cache-dir || {
    echo -e "${YELLOW}Trying fallback version...${RESET}"
    "$PYTHON_PATH" -m pip install flash-attn==2.3.6 --no-build-isolation --no-cache-dir || {
        echo -e "${RED}FlashAttention installation failed${RESET}"
        echo -e "${YELLOW}You can install it later with: ${RESET}"
        echo -e "${YELLOW}  $PYTHON_PATH -m pip install flash-attn==2.3.6 --no-build-isolation${RESET}"
    }
}

echo
echo -e "${GREEN}::::::::::::::: All Done!${RESET}"
echo -e "${YELLOW}Trellis2 should now work in ComfyUI${RESET}"

if [ -z "$1" ]; then
    echo -e "${GREEN}::::::::::::::: ${YELLOW}Press any key to exit${RESET}"
    read -n 1 -s
fi
