#!/bin/bash

# Install Trellis2 wheels from your successful build
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_PATH="$SCRIPT_DIR/../python_embeded/python"
WHEELS_DIR="$SCRIPT_DIR/wheels/Linux/Torch291_cu130"

echo -e "${GREEN}::::::::::::::: Installing Trellis2 Wheels${RESET}"
echo -e "${GREEN}Python: ${YELLOW}$PYTHON_PATH${RESET}"
echo -e "${GREEN}Wheels: ${YELLOW}$WHEELS_DIR${RESET}"
echo

# Core Trellis2 packages
echo -e "${GREEN}::::::::::::::: Installing Core Trellis2 Packages${RESET}"
echo

echo "Installing nvdiffrast..."
"$PYTHON_PATH" -m pip install "$WHEELS_DIR/nvdiffrast-0.4.0-cp312-cp312-linux_x86_64.whl" --force-reinstall --no-deps

echo "Installing cumesh..."
"$PYTHON_PATH" -m pip install "$WHEELS_DIR/cumesh-0.0.1-cp312-cp312-linux_x86_64.whl" --force-reinstall --no-deps

echo "Installing flex_gemm..."
"$PYTHON_PATH" -m pip install "$WHEELS_DIR/flex_gemm-1.0.0-cp312-cp312-linux_x86_64.whl" --force-reinstall --no-deps

echo
echo -e "${GREEN}::::::::::::::: Verifying Installation${RESET}"
echo

# Test imports
packages=("nvdiffrast" "cumesh" "flex_gemm")
for package in "${packages[@]}"; do
    if "$PYTHON_PATH" -c "import $package; print('✓ $package imported successfully')" 2>/dev/null; then
        echo -e "${GREEN}✓ $package is working${RESET}"
    else
        echo -e "${RED}✗ $package failed${RESET}"
    fi
done

echo
echo -e "${GREEN}::::::::::::::: Installation Complete${RESET}"
echo -e "${YELLOW}Trellis2 dependencies are ready for use!${RESET}"
