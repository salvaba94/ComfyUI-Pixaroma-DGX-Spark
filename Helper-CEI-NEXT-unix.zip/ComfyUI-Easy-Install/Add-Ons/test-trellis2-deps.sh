#!/bin/bash

# Test script to verify Trellis2 dependencies
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_PATH="$SCRIPT_DIR/../python_embeded/python"

echo -e "${green}::::::::::::::: Testing Trellis2 Dependencies${reset}"
echo

# Test nvdiffrast
echo -e "${yellow}Testing nvdiffrast...${reset}"
if "$PYTHON_PATH" -c "import nvdiffrast; print('✓ nvdiffrast version:', nvdiffrast.__version__)" 2>/dev/null; then
    echo -e "${green}✓ nvdiffrast is working${reset}"
else
    echo -e "${red}✗ nvdiffrast not found${reset}"
fi
echo

# Test flex_gemm
echo -e "${yellow}Testing flex_gemm...${reset}"
if "$PYTHON_PATH" -c "import flex_gemm; print('✓ flex_gemm imported successfully')" 2>/dev/null; then
    echo -e "${green}✓ flex_gemm is working${reset}"
else
    echo -e "${red}✗ flex_gemm not found${reset}"
fi
echo

# Test CUDA
echo -e "${yellow}Testing CUDA...${reset}"
if "$PYTHON_PATH" -c "import torch; print('✓ CUDA available:', torch.cuda.is_available()); print('✓ GPU:', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'No GPU')" 2>/dev/null; then
    echo -e "${green}✓ CUDA is working${reset}"
else
    echo -e "${red}✗ CUDA not available${reset}"
fi
echo

echo -e "${green}::::::::::::::: Test Complete${reset}"
