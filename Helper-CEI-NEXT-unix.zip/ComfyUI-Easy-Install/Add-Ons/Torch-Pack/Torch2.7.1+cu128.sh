#!/bin/bash

# Title: Torch 2.7.1 (cu128) for 'ComfyUI Easy Install' by ivo
# Pixaroma Community Edition

set -euo pipefail
cd "$(dirname "$0")"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

# PIP args
PIPargs=(--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --root-user-action=ignore)

echo -e "${GREEN}::::::::::::::: Torch 2.7.1 (cu128) installer for Linux :::::::::::::::${RESET}"

# Locate embedded Python
# Note: Script runs from Add-Ons/Torch-Pack, so need to go up one level
PYTHON=""

# Try different possible locations for embedded Python (matching main installer)
if [ -f "../../python_embeded/python" ]; then
  PYTHON="../../python_embeded/python"
  echo -e "${GREEN}✓${RESET} Using embedded Python"
elif [ -f "../../python_embeded/bin/python3" ]; then
  PYTHON="../../python_embeded/bin/python3"
  echo -e "${GREEN}✓${RESET} Using embedded Python 3"
elif [ -f "../../python_embeded/bin/python" ]; then
  PYTHON="../../python_embeded/bin/python"
  echo -e "${GREEN}✓${RESET} Using embedded Python"
elif [ -f "../../python_embeded/python3" ]; then
  PYTHON="../../python_embeded/python3"
  echo -e "${GREEN}✓${RESET} Using embedded Python 3"
elif [ -f "../python_embeded/python" ]; then
  PYTHON="../python_embeded/python"
  echo -e "${GREEN}✓${RESET} Using embedded Python"
elif [ -f "../python_embeded/bin/python3" ]; then
  PYTHON="../python_embeded/bin/python3"
  echo -e "${GREEN}✓${RESET} Using embedded Python 3"
elif [ -f "../python_embeded/bin/python" ]; then
  PYTHON="../python_embeded/bin/python"
  echo -e "${GREEN}✓${RESET} Using embedded Python"
elif [ -f "../python_embeded/python3" ]; then
  PYTHON="../python_embeded/python3"
  echo -e "${GREEN}✓${RESET} Using embedded Python 3"
fi

if [ -z "$PYTHON" ]; then
  echo -e "${RED}✗ Embedded Python not found!${RESET}"
  echo -e "${YELLOW}Expected locations:${RESET}"
  echo -e "    ../python_embeded/python"
  echo -e "    ../python_embeded/bin/python3"
  echo -e "${YELLOW}Run this from the 'ComfyUI-Easy-Install/Add-Ons/Torch-Pack' folder.${RESET}"
  exit 1
fi

echo -e "${GREEN}✓${RESET} Python path: ${YELLOW}$PYTHON${RESET}"

# Check currently installed versions
echo -e "\n${CYAN}::::::::::::::: Currently Installed Versions :::::::::::::::${RESET}"
CURRENT_TORCH=$("$PYTHON" -c "import torch; print(torch.__version__)" 2>/dev/null || echo "Not installed")
CURRENT_TORCHVISION=$("$PYTHON" -c "import torchvision; print(torchvision.__version__)" 2>/dev/null || echo "Not installed")
CURRENT_TORCHAUDIO=$("$PYTHON" -c "import torchaudio; print(torchaudio.__version__)" 2>/dev/null || echo "Not installed")
CURRENT_CUDA=$("$PYTHON" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'N/A')" 2>/dev/null || echo "N/A")

echo -e "    ${YELLOW}torch:${RESET}       $CURRENT_TORCH"
echo -e "    ${YELLOW}torchvision:${RESET} $CURRENT_TORCHVISION"
echo -e "    ${YELLOW}torchaudio:${RESET}  $CURRENT_TORCHAUDIO"
echo -e "    ${YELLOW}CUDA:${RESET}        $CURRENT_CUDA"
echo -e "${CYAN}::::::::::::::: Target Versions :::::::::::::::${RESET}"
echo -e "    ${GREEN}torch:${RESET}       2.7.1"
echo -e "    ${GREEN}torchvision:${RESET} 0.22.1"
echo -e "    ${GREEN}torchaudio:${RESET}  2.7.1"
echo -e "    ${GREEN}CUDA:${RESET}        12.8"
echo ""

# Clear pip cache - DISABLED to avoid slow connection issues
# CACHE_DIR="${XDG_CACHE_HOME:-$HOME/.cache}/pip/cache"
# if [ -d "$CACHE_DIR" ]; then
#   rm -rf "$CACHE_DIR" || true
# fi
# mkdir -p "$CACHE_DIR"
# echo -e "${GREEN}::::::::::::::: Clearing Pip Cache ${YELLOW}Done${GREEN} :::::::::::::::${RESET}\n"

# Uninstall existing torch packages
echo -e "${CYAN}Uninstalling existing torch packages...${RESET}"
"$PYTHON" -I -m pip uninstall torch torchvision torchaudio -y --root-user-action=ignore || true
"$PYTHON" -I -m pip uninstall llama-cpp-python -y --root-user-action=ignore || true

# Install target versions
echo -e "${GREEN}::::::::::::::: Updating${YELLOW} Torch 2.7.1 ${GREEN}:::::::::::::::${RESET}\n"
"$PYTHON" -I -m pip install torch==2.7.1 torchvision==0.22.1 torchaudio==2.7.1 --index-url https://download.pytorch.org/whl/cu128 "${PIPargs[@]}"
"$PYTHON" -I -m pip install https://github.com/JamePeng/llama-cpp-python/releases/download/v0.3.24-cu128-Basic-linux-20260208/llama_cpp_python-0.3.24+cu128.basic-cp312-cp312-linux_x86_64.whl "${PIPargs[@]}"

# Final messages
echo
echo -e "${GREEN}::::::::::::::::::::::: Installation Complete ::::::::::::::::::::::${RESET}"
echo -e "    ${RED}!!! Make sure to reinstall SageAttention and Nunchaku !!!${RESET}"
